import os
ignorado = []
documentofinal = []
print('Qual o nome do seu dicionario?')
book = str(input())
if book[-4:] != '.txt':
    book = book + '.txt'
print('Qual o nome do seu documento?')
text = str(input())
if text[-4:] != '.txt':
    text = text + '.txt'
os.system('clear')

def aceita(word):
    ignorado.append(word)
    with open(book, 'a') as dic:
        dic.write(word + '\n')
        dic.close()
    return

def unkword(word):
    ctrl_2 = [1 , 2 , 3]
    while(True):
        print(word + ' é uma palavra desconhecida o que fazer?')
        print('(1) Aceitar\n(2) Ignorar\n(3) Substituir\nInsira um codigo: ',end='')
        try:
            ctrl_1 = int(input())
            ctrl_2.index(ctrl_1)
            break
        except ValueError:
            os.system('clear')
            print('Codigo invalido, insira um valido!\n')
    if ctrl_1 == 1:   #aceite
        aceita(word)
        print('aceito')
        return word
    elif ctrl_1 == 2: #ignore
        print('ignorado')
        ignorado.append(word)
        return word
    elif ctrl_1 == 3: #substitua
        print('Por qual palavra?')
        substituta = input()
        print('substituido')
        return substituta
#        i = documento.index(word)
#        documento[i] = substituta

def elem(palavra, dicionario):
    try:
        dicionario.index(palavra)
    except ValueError:
        try:
            ignorado.index(palavra)
        except ValueError:
            raise ValueError

with open(book, 'r') as dic:
    dicionario = dic.read().split()
    dic.close()

with open(text, 'r') as doc:
    texto = doc.readlines()
    temp = [line[:-1] for line in texto]
    for line in texto:
        linha = line.split()
        for word in linha:
            try:
                elem(word,dicionario)
#                dicionario.index(word)
                documentofinal.append(word)
            except ValueError:
#                print(word)
                fst = word[1:]
                chfst = word[0]
                lst = word[:-1]
                chlst = word[-1]
                mid = word[1:-1]
                try:
                    elem(fst,dicionario)
#                    dicionario.index(fst)
                    documentofinal.append(chfst+fst)
                except ValueError:
#                    print(fst)
                    try:
                        elem(lst,dicionario)
#                        dicionario.index(lst)
                        documentofinal.append(lst+chlst)
                    except ValueError:
#                        print(lst)
                        try:
                            elem(mid,dicionario)
#                            dicionario.index(mid)
                            documentofinal.append(chfst+mid+chlst)
                        except ValueError:
#                            print(mid)
                            documentofinal.append(unkword(word))
                            os.system('clear')
            documentofinal.append(' ')
        documentofinal.append('\n')
doc.close()

with open(text, 'w') as doc:
    for line in documentofinal:
        doc.write(str(line))
    doc.close()
    
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
